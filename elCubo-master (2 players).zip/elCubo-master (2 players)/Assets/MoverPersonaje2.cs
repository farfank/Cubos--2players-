﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//Crear un objeto: Instantiate(ElObjeto, new Vector3(0f,0f,1.5f)+transform.position,transform.rotation);
//Destruir: Destroy(gameObject);
//void OncollisionEnter(Collider col){}
public class MoverPersonaje2 : MonoBehaviour {
    public float movementSpeed = 5f;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        transform.Translate(new Vector3(0f, 0f, Input.GetAxis("Verticall")) *
            Time.deltaTime
            * movementSpeed);
        transform.Rotate(new Vector3(0f, Input.GetAxis("Horizontall"), 0f));

    }
}
