# elCubo
Proyecto inicial en Unity en que se logra mover un cubo con el teclado usando script
